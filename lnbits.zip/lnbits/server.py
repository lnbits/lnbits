from flask import Flask, render_template
from flask import Flask, redirect
from flask import request
from flask import jsonify
from flask import Flask, g
from random import seed
from random import random
from flask import json
import os
import sqlite3
import base64
import lnurl
import requests 
import hashlib
import time
import json

#DATABASE = 'database.db'

INVOICE_KEY = "MzAwMjE6MWUyOTlkZDc5MzFiMTQxNThjNDc4OWJiNGZkMjhlMzMxNzk1NGY3ZjRkYTgzYmNlOWFjNTJmZDUyYTc1MGI3ZQ=="
API_ENDPOINT = "https://lntxbot.bigsun.xyz"

app = Flask(__name__)


DEFAULT_PATH = "database.sqlite3"


def db_connect(db_path=DEFAULT_PATH):
    con = sqlite3.connect(db_path)
    return con

def encrypt_string(hash_string):
    sha_signature = \
        hashlib.sha256(hash_string.encode()).hexdigest()
    return sha_signature


@app.route('/')
def home():

	return render_template('index.html')

@app.route('/deletewallet')
def deletewallet():

	thewal = request.args.get('wal');

	con = db_connect() 
	cur = con.cursor() 
	print(thewal)
	cur.execute("select * from wallets WHERE hash = '" + str(thewal) + "'")
	rowss = cur.fetchall()

	if len(rowss) > 0:
		
		cur.close()
		print(rowss)

		userupt = "del" + rowss[0][4]

		con = db_connect() 
		cur = con.cursor() 

		cur.execute("UPDATE wallets SET user = '" + userupt + "' WHERE hash = '" + rowss[0][0] + "'")

		con.commit()
		cur.close()

		con = db_connect() 
		cur = con.cursor() 
		print(thewal)
		cur.execute("select * from wallets WHERE user = '" + rowss[0][4] + "'")
		rowsss = cur.fetchall()

		if len(rowsss) > 0:
			cur.close()
			return render_template('deletewallet.html', theid = rowsss[0][4], thewal = rowsss[0][0])
		else:
			return render_template('index.html')

	else:	
		return render_template('index.html')





	
@app.route('/getinvoice')
def getinvoice():
    
	amt = request.args.get('amt');
	nme = request.args.get('nme');

	dataj = {'amt': amt, 'memo': nme} 
	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}


	r = requests.post(url = API_ENDPOINT + "/addinvoice", json = dataj, headers = headers) 
	  
	data = r.json() 

	pay_req = data['pay_req']
	payment_hash = data['payment_hash']

	return jsonify({"pay_req": pay_req, "payment_hash": payment_hash}), 200

@app.route('/paymentadd')
def paymentadd():
	thehash = request.args.get('hash');
	theamt = request.args.get('amt');
	thenme = request.args.get('nme');
	thewall = request.args.get('wal');

	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}
	r = requests.post(url = API_ENDPOINT + "/invoicestatus/" + thehash, headers = headers) 
	data = r.json() 
	print(data)

    
	if data == "":
		return jsonify({"paid": "false"}), 200
	else:
		con = db_connect() 
		cur = con.cursor() 

		cur.execute("select * from wallets WHERE hash = '" + str(thewall) + "'")
	 
		rows = cur.fetchall()
		print(rows)
        
		lastamt = rows[0][1].split(",")
		newamt = int(lastamt[-1]) + int(theamt)
		updamt = rows[0][1] + "," + str(newamt)

		thetime = time.time()
		transactions = "!" + thenme + "," + str(thetime) + "," + str(theamt)

		con = db_connect() 
		cur = con.cursor() 

		cur.execute("UPDATE wallets SET transactions = '" + rows[0][2] + transactions + "' WHERE hash = '" + str(thewall) + "'")
		
		con.commit()
		cur.close()

		con = db_connect() 
		cur = con.cursor() 

		cur.execute("UPDATE wallets SET balance = '" + updamt + "' WHERE hash = '" + str(thewall) + "'")
		
		con.commit()
		cur.close()
		
		return jsonify({"paid": "true","wal": thewall}), 200


  
@app.route('/lnurlwallet')
def lnurlwallet():

	#put in a function
	thestr = request.args.get('lightning');
	lnurll = lnurl.decode(thestr)
	r = requests.get(url = lnurll) 

	data = r.json() 
	print(data)

	callback = data['callback']
	maxwithdraw = data['maxWithdrawable']
	withdraw = int(maxwithdraw/1000)
	k1 = data['k1']

	#get invoice
	dataj = {'amt': str(withdraw)} 
	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}

	rr = requests.post(url = API_ENDPOINT + "/addinvoice", json = dataj, headers = headers) 
	  
	dataa = rr.json() 

	#get callback

	pay_req = dataa['pay_req']
	payment_hash = dataa['payment_hash']

	invurl =  callback + '&k1=' + k1 + '&pr=' + pay_req

	rrr = requests.get(url = invurl) 
	dataaa = rrr.json() 

	#database add
	return redirect("wallet?id=" + thestr, code=302)
		
		
@app.route('/wallet')
def wallet():

	theid = request.args.get('usr');
	thewal = request.args.get('wal');
	theamt = request.args.get('amt');
	thenme = request.args.get('nme');

	if not thewal:
		return render_template('index.html')
	else:
		#Checks if the user exists in "accounts"
		con = db_connect() 
		cur = con.cursor() 
		print(thewal)
		cur.execute("select * from accounts WHERE userhash = '" + str(theid) + "'")
		rows = cur.fetchall()

		if len(rows) > 0:
			cur.close()

	        #Yes, check the user has a wallet
			con = db_connect() 
			cur = con.cursor() 
			print(thewal)
			cur.execute("select * from wallets WHERE user = '" + str(theid) + "'")
			rowss = cur.fetchall()

			if len(rowss) > 0:
				cur.close()

				#Checks if the current wallet exists
				con = db_connect() 
				cur = con.cursor() 
				print(thewal)
				cur.execute("select * from wallets WHERE hash = '" + str(thewal) + "'")
				rowsss = cur.fetchall()

				if len(rowsss) > 0:
					cur.close()
					walb = rowsss[0][1].split(",")[-1]
					return render_template('wallet.html', thearr = rowsss, walnme = rowsss[0][3], user = theid, walbal = walb, theid = theid, thewal = thewal, transactions = rowsss[0][2], adminkey = rowsss[0][5], inkey = rowsss[0][6])
				else:
					cur.close()

					con = db_connect() 
					cur = con.cursor() 

					adminkey = encrypt_string(thewal)
					inkey = encrypt_string(adminkey)

					cur.execute("INSERT INTO wallets (hash, balance, transactions, name, user, adminkey, inkey) VALUES ('" + thewal + "',',0','0','" + thenme + "','" + theid + "','" + adminkey + "','" + inkey + "')")
					con.commit()
					cur.close()
					
					return render_template('wallet.html', thearr = rowss, walnme = thenme, walbal = '0', theid = theid, thewal = thewal, adminkey = adminkey, inkey = inkey)
			else:
				cur.close()

				con = db_connect() 
				cur = con.cursor() 

				adminkey = encrypt_string(theid)
				inkey = encrypt_string(adminkey)

				cur.execute("INSERT INTO wallets (hash, balance, transactions, name, user, adminkey, inkey) VALUES ('" + thewal + "',',0','0','" + thenme + "','" + theid + "','" + adminkey + "','" + inkey + "')")
				con.commit()
				cur.close()
					
				return render_template('wallet.html', thearr = rows, walnme = thenme, walbal = '0', theid = theid, thewal = thewal, adminkey = adminkey, inkey = inkey)

		else:
			cur.close()
			con = db_connect() 
			cur = con.cursor() 

			cur.execute("INSERT INTO accounts (userhash) VALUES ('" + theid + "')")
			con.commit()
			cur.close()

			con = db_connect() 
			cur = con.cursor() 

			adminkey = encrypt_string(theid)
			inkey = encrypt_string(adminkey)

			cur.execute("INSERT INTO wallets (hash, balance, transactions, name, user, adminkey, inkey) VALUES ('" + thewal + "',',0','0','" + thenme + "','" + theid + "','" + adminkey + "','" + inkey + "')")
			con.commit()
			cur.close()

			con = db_connect() 
			cur = con.cursor() 
			print(thewal)
			cur.execute("select * from wallets WHERE user = '" + str(theid) + "'")
			rows = cur.fetchall()
			con.commit()
			cur.close()
					
			return render_template('wallet.html', thearr = rows, walnme = thenme, walbal = '0', theid = theid, thewal = thewal, adminkey = adminkey, inkey = inkey)



#API requests
@app.route('/v1/invoices', methods=['POST'])
def api_invoices():
	if request.headers['Content-Type'] == 'application/json':
		json.dumps(request.json)
		postedjson = json.loads(json.dumps(request.json))

		if "value" in postedjson:
			if postedjson["value"].isdigit() == True:
				if "memo" in postedjson:
					con = db_connect() 
					cur = con.cursor() 
					cur.execute("select * from wallets WHERE inkey = '" + postedjson["Grpc-Metadata-macaroon"] + "'")
					rows = cur.fetchall()

					if len(rows) > 0:
						cur.close()

						
						
						dataj = {'amt': postedjson["value"], 'memo': postedjson["memo"]} 
						headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}


						r = requests.post(url = API_ENDPOINT + "/addinvoice", json = dataj, headers = headers) 
						  
						data = r.json() 

						pay_req = data['pay_req']
						payment_hash = data['payment_hash']

						con = db_connect() 
						cur = con.cursor() 

						cur.execute("INSERT INTO apipayments (payhash, amount, wallet, paid, inkey, memo) VALUES ('" + payment_hash + "','" + postedjson["value"] + "','" + rows[0][0] + "','0','" + postedjson["Grpc-Metadata-macaroon"] + "','" + postedjson["memo"] + "')")
						con.commit()
						cur.close()

						return jsonify({"pay_req": pay_req, "payment_hash": payment_hash}), 200

					else:
						return jsonify({"ERROR": "NO KEY"}), 200
				else:
					return jsonify({"ERROR": "NO MEMO"}), 200
			else:
				return jsonify({"ERROR": "VALUE MUST BE A NUMMBER"}), 200
		else:
			return jsonify({"ERROR": "NO VALUE"}), 200
	else:
		return jsonify({"ERROR": "MUST BE JSON"}), 200


@app.route('/v1/invoice/<payhash>', methods=['GET'])
def api_checkinvoice(payhash):
		
	if request.headers['Content-Type'] == 'application/json':
		json.dumps(request.json)
		postedjson = json.loads(json.dumps(request.json))

		con = db_connect() 
		cur = con.cursor() 
		cur.execute("select * from apipayments WHERE inkey = '" + postedjson["Grpc-Metadata-macaroon"] + "'")
		rows = cur.fetchall()

		if len(rows) > 0:
			cur.close()			
			

			con = db_connect() 
			cur = con.cursor() 
			cur.execute("select * from apipayments WHERE payhash = '" + payhash + "'")
			rowss = cur.fetchall()

			if len(rowss) > 0:
				cur.close()

				headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}
				r = requests.post(url = API_ENDPOINT + "/invoicestatus/" + payhash, headers = headers) 
				data = r.json() 
				print(data)

			    
				if data == "":
					return jsonify({"PAID": "FALSE"}), 200
				else:
					con = db_connect() 
					cur = con.cursor() 

					cur.execute("select * from wallets WHERE hash = '" + rowss[0][2] + "'")
				 
					rowsss = cur.fetchall()

			        
					lastamt = rowsss[0][1].split(",")
					newamt = int(lastamt[-1]) + int(rowss[0][1])
					updamt = rowsss[0][1] + "," + str(newamt)

					thetime = time.time()
					transactions = "!" + rowss[0][5] + "," + str(thetime) + "," + str(rowss[0][1])

					con = db_connect() 
					cur = con.cursor() 

					cur.execute("UPDATE wallets SET transactions = '" + rowsss[0][2] + transactions + "' WHERE hash = '" + rowss[0][2] + "'")
					
					con.commit()
					cur.close()

					con = db_connect() 
					cur = con.cursor() 

					cur.execute("UPDATE wallets SET balance = '" + updamt + "' WHERE hash = '" + rowss[0][2]  + "'")
					
					con.commit()
					cur.close()
					
					return jsonify({"PAID": "TRUE"}), 200
			else:
				return jsonify({"ERROR": "NO RECORD OF HASH"}), 200
		else:
			return jsonify({"ERROR": "NO KEY"}), 200
	else:
		return jsonify({"ERROR": "MUST BE JSON"}), 200




if __name__ == '__main__':
    app.run(debug=True)