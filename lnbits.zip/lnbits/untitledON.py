from flask import Flask, render_template
from flask import Flask, redirect
from flask import request
from flask import jsonify
from flask import Flask, g
import os
import sqlite3
import base64
import lnurl
import requests 


#DATABASE = 'database.db'

INVOICE_KEY = "MzAwMjE6MWUyOTlkZDc5MzFiMTQxNThjNDc4OWJiNGZkMjhlMzMxNzk1NGY3ZjRkYTgzYmNlOWFjNTJmZDUyYTc1MGI3ZQ=="
API_ENDPOINT = "https://lntxbot.bigsun.xyz"

app = Flask(__name__)


DEFAULT_PATH = "database.sqlite3"

def db_connect(db_path=DEFAULT_PATH):
    con = sqlite3.connect(db_path)
    return con



@app.route('/')
def home():

	return render_template('index.html')

	
@app.route('/getinvoice')
def getinvoice():
    
	amt = request.args.get('amt');
	nme = request.args.get('nme');

	dataj = {'amt': amt, 'memo': nme} 
	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}


	r = requests.post(url = API_ENDPOINT + "/addinvoice", json = dataj, headers = headers) 
	  
	data = r.json() 

	pay_req = data['pay_req']
	payment_hash = data['payment_hash']

	return jsonify({"pay_req": pay_req, "payment_hash": payment_hash}), 200


@app.route('/paymentcheck')
def paymentcheck():
	thehash = request.args.get('hash');
	theamt = request.args.get('amt');
	thenme = request.args.get('nme');

	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}
	r = requests.post(url = API_ENDPOINT + "/invoicestatus/" + thehash, headers = headers) 
	data = r.json() 
	print(data)

    
	if data == "":
		return jsonify({"paid": "false"}), 200
	else:
		#database add

		con = db_connect() 
		cur = con.cursor() 

		cur.execute("INSERT INTO accounts (userhash, wallets) VALUES ('" + thehash + "','" + thehash + ",')")
		con.commit()
		cur.close()

		con = db_connect() 
		cur = con.cursor() 

		cur.execute("INSERT INTO wallets (hash, balance, name) VALUES ('" + thehash + "','" + theamt + ",','" + thenme + "')")
		con.commit()
		cur.close()
		return jsonify({"paid": "true","userhash": thehash}), 200


@app.route('/paymentadd')
def paymentadd():
	thehash = request.args.get('hash');
	theamt = request.args.get('amt');
	thenme = request.args.get('nme');
	thewall = request.args.get('wal');

	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}
	r = requests.post(url = API_ENDPOINT + "/invoicestatus/" + thehash, headers = headers) 
	data = r.json() 
	print(data)

    
	if data == "":
		return jsonify({"paid": "false"}), 200
	else:
		#database add

		con = db_connect() 
		cur = con.cursor() 

		cur.execute("select * from wallets WHERE hash = '" + thewall + "'")
	 
		rows = cur.fetchall()
		print(rows[0][1])
		balance = rows[0][1].split(",")

		upbal = str(int(balance[-1]) + int(theamt))
		print(upbal)

		upball = balance[-1] + upbal
		print(upball)

		cur.close()

		con = db_connect() 
		cur = con.cursor() 

		cur.execute("INSERT INTO wallets WHERE hash = '" + thewall + "' (balance) VALUES ('" + updbal + "')")
		con.commit()
		cur.close()

		return jsonify({"paid": "true","userhash": thewall}), 200


@app.route('/test')
def test():
	
	return jsonify({"paid": "true"}), 200

  
@app.route('/lnurlwallet')
def lnurlwallet():

	#put in a function
	thestr = request.args.get('lightning');
	lnurll = lnurl.decode(thestr)
	r = requests.get(url = lnurll) 

	data = r.json() 
	print(data)

	callback = data['callback']
	maxwithdraw = data['maxWithdrawable']
	withdraw = int(maxwithdraw/1000)
	k1 = data['k1']

	#get invoice
	dataj = {'amt': str(withdraw)} 
	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}

	rr = requests.post(url = API_ENDPOINT + "/addinvoice", json = dataj, headers = headers) 
	  
	dataa = rr.json() 

	#get callback

	pay_req = dataa['pay_req']
	payment_hash = dataa['payment_hash']

	invurl =  callback + '&k1=' + k1 + '&pr=' + pay_req

	rrr = requests.get(url = invurl) 
	dataaa = rrr.json() 

	#database add
	return redirect("wallet?id=" + thestr, code=302)
		
	

@app.route('/wallet')
def wallet():

	userhash = request.args.get('id');


	con = db_connect() 
	cur = con.cursor() 

	cur.execute("select * from accounts WHERE userhash = '" + userhash + "'")
 
	rows = cur.fetchall()
	cur.close()
	wallet = rows[0][3].replace(',', '')
	print(rows[0][3])
	con = db_connect() 
	cur = con.cursor() 

	cur.execute("select * from wallets WHERE hash = '" + wallet + "'")
 
	rowss = cur.fetchall()

	cur.close()
	
	return render_template('wallet.html', wallet = wallet, walnme = rowss[0][4], walbal = rowss[0][1].replace(',', ''))




if __name__ == '__main__':
    app.run(debug=True)

