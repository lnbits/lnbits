import sqlite3

conn = sqlite3.connect('data.sqlite3')
print("Opened database successfully");

conn.execute('CREATE TABLE accounts (userhash TEXT, email TEXT, pass TEXT)')
print("Table created successfully");
conn.close()