from flask import Flask, render_template
from flask import request
import lnurl
import requests 

maxwithdraw = 200

API_ENDPOINT = "https://lntxbot.bigsun.xyz/addinvoice"

INVOICE_KEY = "MzAwMjE6MWUyOTlkZDc5MzFiMTQxNThjNDc4OWJiNGZkMjhlMzMxNzk1NGY3ZjRkYTgzYmNlOWFjNTJmZDUyYTc1MGI3ZQ=="

data = {'amt':'200'} 
headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}

r = requests.post(url = API_ENDPOINT, json = data, headers = headers) 
	  
data = r.json() 

print(data) 





from flask import Flask, render_template
from flask import request
import lnurl
import requests 

	
app = Flask(__name__)
@app.route('/')
def home():

	maxwithdraw = 200

	API_ENDPOINT = "https://lntxbot.bigsun.xyz/addinvoice"

	INVOICE_KEY = "MzAwMjE6MWUyOTlkZDc5MzFiMTQxNThjNDc4OWJiNGZkMjhlMzMxNzk1NGY3ZjRkYTgzYmNlOWFjNTJmZDUyYTc1MGI3ZQ=="

	data = {'amt':'200'} 
	headers = {'Authorization': 'Basic %s' %  INVOICE_KEY}

	r = requests.post(url = API_ENDPOINT, json = data, headers = headers) 
	  
	data = r.json() 

	print(data) 


	return render_template('index.html', maxwithdraw = maxwithdraw)
if __name__ == '__main__':
    app.run(debug=True)

